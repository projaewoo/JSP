package com.example.libs.service;

import java.sql.SQLException;

import com.example.libs.model.MemberDao;
import com.example.libs.model.MemberVO;

public class InsertService {

	public int insertMember (MemberVO member) {		//member 메소드 : 주소로 호출.
		int row = -1;
		try {
			row = MemberDao.register(member);
		} catch (SQLException e) {
			System.out.println(e);
		}
		return row;
	}
	
}