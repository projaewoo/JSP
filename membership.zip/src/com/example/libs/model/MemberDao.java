package com.example.libs.model;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.OracleTypes;

public class MemberDao {
	
	//회원가입 위한 메소드
	public static int register(MemberVO member) throws SQLException {
		Connection conn = DBConnection.getConnection();		//2, 3step
		String sql = "{ call sp_member_insert(?, ?, ?, ?, ?, ?, ?) }";
		CallableStatement cstmt = conn.prepareCall(sql);		//4step
		cstmt.setString(1, member.getUserid());
		cstmt.setString(2, member.getPasswd());
		cstmt.setString(3, member.getName());
		cstmt.setString(4, member.getEmail());
		cstmt.setString(5, member.getGender());
		cstmt.setString(6, member.getCity());
		cstmt.setInt(7, member.getAge());	
		
		int row = cstmt.executeUpdate();		//5step	//변동된 row의 갯수를 저장.		
		
		DBClose.close(conn, cstmt);		//6step.
		return row;
	}

	//로그인하는 메소드
	//3가지 경우
		//	-1 : 존재하지 않는 아이디
		//	0 : 아이디는 있으나 비밀번호 일치하지 않음
		//	1 : 모두 일치
	public static int login(String userid, String passwd) throws SQLException {
		Connection conn = DBConnection.getConnection();		//2, 3 step
		String sql = "{ call sp_member_login(?, ?) }";
		CallableStatement cstmt = conn.prepareCall(sql);		//4step
		cstmt.setString(1, userid);
		cstmt.registerOutParameter(2, OracleTypes.CURSOR); 		//DB에서 나오는 변수 (out변수) : registerOutParameter()로 받음.
		cstmt.execute(); 		//매우 주의!!		//나오는건 항상 execute()사용.

		Object obj = cstmt.getObject(2);		//커서를 Object로 받음.
		ResultSet rs = (ResultSet)obj;		//강제 형변환.
		
		int key = -2;
		if(rs.next()) {		//아이디에 맞는 비밀번호를 가져왔다면
			String db_passwd = rs.getString("passwd");		//DB에서 가져온 비밀번호
			if(db_passwd.trim().equals(passwd.trim())) {
				key = 1;			//아이디, 비밀번호 모두 일치
			}else {
				key = 0;			//비밀번호 불일치.
			}
		}else {		//아예 그런 아이디가 없다면
			key = -1;
		}
		
		DBClose.close(conn, cstmt);			//7step.
		return key;
	}
	
}
