/* 회원 */
CREATE TABLE scott.Member (
	userid CHAR(14) NOT NULL, /* 아이디 */
	passwd CHAR(10) NOT NULL, /* 비밀번호 */
	name VARCHAR2(20) NOT NULL, /* 회원이름 */
	email VARCHAR2(50) NOT NULL, /* 회원이메일 */
	gender CHAR(1) DEFAULT 2 NOT NULL, /* 성별 */
	city VARCHAR2(20), /* 거주지 */
	age NUMBER(3) /* 나이 */
);

COMMENT ON TABLE scott.Member IS '회원';

COMMENT ON COLUMN scott.Member.userid IS '아이디';

COMMENT ON COLUMN scott.Member.passwd IS '비밀번호';

COMMENT ON COLUMN scott.Member.name IS '회원이름';

COMMENT ON COLUMN scott.Member.email IS '회원이메일';

COMMENT ON COLUMN scott.Member.gender IS '성별';

COMMENT ON COLUMN scott.Member.city IS '거주지';

COMMENT ON COLUMN scott.Member.age IS '나이';

CREATE UNIQUE INDEX scott.PK_Member
	ON scott.Member (
		userid ASC
	);

ALTER TABLE scott.Member
	ADD
		CONSTRAINT PK_Member
		PRIMARY KEY (
			userid
		);
		
-- Stored Procedure (커서 사용) 작성		
--아이디에 해당하는 비밀번호를 Dao에게 넘기는 프로시저.
create or replace NONEDITIONABLE PROCEDURE sp_member_login
(
    v_userid   IN     member.userid%TYPE,
    login_record   OUT     SYS_REFCURSOR			--DB에서 dao로 CURSOR가 넘어감.
)
IS
BEGIN
    OPEN login_record FOR
    SELECT passwd FROM Member
    WHERE userid = v_userid;
END;

--INSERT하는 Stored Procedure 작성
CREATE OR REPLACE PROCEDURE sp_member_insert
(   
    v_userid      IN member.userid%TYPE,
    v_passwd      IN member.passwd%TYPE,
    v_name        IN member.name%TYPE,
    v_email       IN member.email%TYPE,
    v_gender      IN member.gender%TYPE,
    v_city        IN member.city%TYPE,
    v_age         IN member.age%TYPE
)
IS
BEGIN
    INSERT INTO Member          --Member테이블에 values들을 넣기
    VALUES(v_userid, v_passwd, v_name, v_email, v_gender, v_city, v_age);
    COMMIT;
END;